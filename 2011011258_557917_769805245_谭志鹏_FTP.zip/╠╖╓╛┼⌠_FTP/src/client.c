#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<limits.h>
#include<string.h>
#include<ctype.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<netdb.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<errno.h>
#include<dirent.h>


#define LOCAL_IP "127.0.0.1"
#define SERVER_PORT 2049
#define DATA_PORT 2048
#define MAX_INPUT_SIZE 254
#define FILEBUF_SIZE 1024

//information about server and local ip, port
char *server_ip, *local_ip;
int server_port, local_port;

//server_sock use to transmit the command, data_sock use to transmit the data
int server_sock, client_sock = -1, data_sock;
struct sockaddr_in server_addr, client_addr, data_addr;
struct hostent *server_host;


char buffer[FILEBUF_SIZE];   //use buffer to store the information get
char input_line[MAX_INPUT_SIZE+1];   
int tmp = 0;


//send msg to server
void send_msg(char *command, char *msg, int flag);

//some functions
void command_quit();
void command_pwd();
void command_cd();
void command_list();
void command_get(char *filename);
void command_put(char *filename);
void help_info();

//create data connection
int command_port();


int main(int argv, char **argc)
{
    server_ip = LOCAL_IP;
    server_port = SERVER_PORT;
    
    //get server host
    server_host = gethostbyname(server_ip);
    if(server_host == (struct hostent *)NULL)
    {
	printf(">gethostbyname failed\n");
	exit(1);
    }
    //create the server_socket, used as command socket
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    memcpy(&server_addr.sin_addr, server_host->h_addr, server_host->h_length);
    server_addr.sin_port = htons(server_port);

    server_sock = socket(PF_INET, SOCK_STREAM, 0);
    if(server_sock < 0)
    {
	printf(">error on socket()\n");
	exit(1);
    }
    //connect to the server
    if(connect(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
	printf(">error on connect()\n");
	close(server_sock);
	exit(1);
    }
    
    //get welcome information
    printf(">Connected to the ftp\n");
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);

    while(1)
    {
	printf(">");

        //get the command input
	fgets(input_line, MAX_INPUT_SIZE, stdin);
	input_line[strlen(input_line)-1] = '\0';

        //deal with the command
	if(strncmp("quit", input_line, 4) == 0)
	{
	    command_quit();
	    break;
	}
	else if((strncmp("?", input_line, 1) == 0) || (strncmp("help", input_line, 4) == 0))
	{
	    help_info();
	}
	else if(strncmp("pwd", input_line, 3) == 0)
	{
	    command_pwd();
	}
	else if(strncmp("cd", input_line, 2) == 0)
	{
	    command_cd();
	}

	else if((strncmp("ls", input_line, 2) == 0) || (strncmp("dir", input_line, 3) == 0))
	{
	    command_list();
	}
	else if(strncmp("get", input_line, 3) == 0)
	{
	    command_get(&input_line[4]);
	}
	else if(strncmp("put", input_line, 3) == 0)
	{
	    command_put(&input_line[4]);
	}
	
    }

    //close the socket
    close(server_sock);
    return 0;
}



//send msg to server
void send_msg(char *command, char *msg, int flag)
{
    char reply[MAX_INPUT_SIZE+1];
    if(flag == 0)
	sprintf(reply, "%s\r\n", command);
    else
	sprintf(reply, "%s %s\r\n", command, msg);
    write(server_sock, reply, strlen(reply));
    return;
}

//print help information
void help_info()
{
    printf("?\tcd\tdir\tls\n");
    printf("help\t\n");
    printf("pwd\tget\tput\tquit\n");
}


void command_quit()
{
    send_msg("QUIT", "", 0);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
}

void command_pwd()
{
    send_msg("PWD", "", 0);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
}

void command_cd()
{
    send_msg("CWD", &input_line[3], 1);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
}



void command_list()
{
    unsigned char databuf[PIPE_BUF];
    int bytes = 0, bytesread = 0;
    
    //create the data socket to transfer the data
    if(command_port() == -1) return;

    //send command
    send_msg("LIST", "", 0);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
    
    // Read from the socket and write to stdout 
    while ((bytes = read(data_sock, databuf, sizeof(databuf)) > 0)) {

	printf("%s", databuf);
	bytesread += bytes;
    }
    
    // Close the data socket 
    close(data_sock);
    
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
}

void command_get(char *filename)
{
    FILE *outfile;
    short file_open=0;
    unsigned char databuf[FILEBUF_SIZE];
    int bytes = 0, bytesread = 0;
    
    //create the data socket to transfer the data
    if(command_port() == -1) return;
    send_msg("GETF", filename, 1);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
    
    // Read from the socket and write to the file 
    while ((bytes = read(data_sock, databuf, FILEBUF_SIZE)) > 0) {
	if (file_open == 0) {
	    // Open the file the first time we  read data 
	    if ((outfile = fopen(filename, "w")) == 0) {
		printf("fopen failed to open file");
		close(data_sock);
		return;
	    }
	    file_open = 1;
	}
	write(fileno(outfile), databuf, bytes);
	bytesread += bytes;
    }
    // Close the file and socket 
    if (file_open != 0)
         fclose(outfile);
    close(data_sock);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);

}

void command_put(char *filename)
{
    FILE *infile;
    unsigned char databuf[FILEBUF_SIZE] = "";
    int bytes, bytessend;
    
    //open the file
    infile = fopen(filename,"r");
    if(infile == 0)
    {
	perror("fopen() failed");
	close(data_sock);
	return;
    }
    
    //create the data socket to transfer the data
    if(command_port() == -1) return;
    send_msg("PUTF", filename, 1);
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);

    // Read from the file and write to the socket
    while((bytes = read(fileno(infile), databuf, FILEBUF_SIZE)) > 0)
    {
	write(data_sock, (const char *)databuf, bytes);
	bytessend += bytes;
	memset(&databuf, 0, FILEBUF_SIZE);
    }

    memset(&databuf, 0, FILEBUF_SIZE);

    // Close the file and socket     
    fclose(infile);
    close(data_sock);
    
    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);

}


//create data path
int command_port()
{
    //create client socket
    if(client_sock < 0)
    {
	    client_sock = socket(PF_INET, SOCK_STREAM, 0);
	    if(client_sock == -1)	//create socket failed
	    {
		close(client_sock);
		printf("data socket() failed");
		return -1;
	    }
	    //configure server address,port
	    memset(&client_addr, 0 ,sizeof(client_addr));
	    socklen_t client_addr_len = sizeof client_addr;
	    client_addr.sin_family = AF_INET;
	    client_addr.sin_port = htons(DATA_PORT);
	    //client_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	    client_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);
	    if(client_addr.sin_addr.s_addr == INADDR_NONE)
	    {
		printf("INADDR_NONE");
		return -1;
	    }	    
	    //bind
	    tmp = bind(client_sock, (struct sockaddr *)&client_addr, client_addr_len);
	    if(tmp == -1)
	    {
		close(client_sock);
		perror("data_sock bind() failed\n");
		return -1;
	    }    
	    //listen
	    tmp = listen(client_sock, 1);
	    if(tmp < 0)
	    {
		close(client_sock);
		printf("data_sock listen() failed!\n");
		return -1;
	    }
	    printf("data conn listening...\n");
    }
    //demand the server to connect
    char port_addr[24] = "";
    send_msg("PORT", port_addr, 1);

    tmp = read(server_sock, buffer, sizeof(buffer));
    buffer[tmp-2] = 0;
    printf("%s\n", buffer);
    
    //accept to get data_sock
    socklen_t data_addr_len = sizeof data_addr;
    memset(&data_addr, 0, sizeof data_addr);
    data_sock = accept(client_sock, (struct sockaddr *)&data_addr, &data_addr_len);
    if(data_sock < 0)
    {
	printf("data_sock accept failed!\n");
	return -1;
    }
    return 0;
}
