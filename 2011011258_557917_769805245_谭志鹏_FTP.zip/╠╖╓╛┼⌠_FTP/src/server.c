#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<limits.h>
#include<string.h>
#include<ctype.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<netdb.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<errno.h>
#include<dirent.h> 


#define SERVER_PORT 2049
#define DATA_PORT 2048
#define FILEBUF_SIZE 1024
#define MAX_INPUT_SIZE 254


//client_scok is command socket, data_sock use to transfer data
int server_sock, client_sock, data_sock;    
struct sockaddr_in server_addr, client_addr, data_addr;


void command_pwd(char *reply);
void command_cwd(char *dir);
void command_list(char *reply);
void command_get(char *filename, char *reply);
void command_put(char *filename, char *reply);
void command_port(char *params, char *reply);  

//buffer use to store the info
char buffer[FILEBUF_SIZE];
int tmp;


void reporterror(const char *on_what)
{
    perror(on_what);
    exit(1);
}


int main(int argc, char **argv)
{
  
    //create server socket
    server_sock = socket(PF_INET, SOCK_STREAM, 0);
    if(server_sock == -1)	//create socket failed
    {
	reporterror("socket() failed");
    }
    else printf("Socket created!\n");
    
    //configure server address,port
    memset(&server_addr, 0 ,sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    //server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if(server_addr.sin_addr.s_addr == INADDR_NONE)
    {
	reporterror("INADDR_NONE");
    }
    
    //bind
    tmp = bind(server_sock, (struct sockaddr *)&server_addr, sizeof server_addr);
    if(tmp == -1)
    {
	reporterror("bind()");
    }
    else printf("Bind Ok!\n");
    
    //listen
    tmp = listen(server_sock, 5);
    if(tmp < 0)
    {
	printf("Server Listen Failed!");
	exit(1);
    }
    else printf("listening\n");
    
    //wait for connection
    while(1)
    {
	socklen_t client_addr_len = sizeof(client_addr);
	printf("wait for accept...\n");

	//accept an request from client
	client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &client_addr_len);
	if(client_sock < 0)
	{
	    printf("Server Accept Failed!\n");
	    return 1;
	}
	else printf("Server Accept Succeed!\n");
        
        //send welcome information to the client
	char reply[100] = "FTP server is ready\r\n";
	write(client_sock, reply, strlen(reply));
	printf("--->%s",reply);
	while(1){    
	    //read into the buffer
	    tmp = read(client_sock, buffer, sizeof(buffer));
	    buffer[tmp-2] = 0;

	    char command[5];
	    strncpy(command, buffer, 3);
	    command[3] = 0;

	    //deal with the commands
	    if(strcmp(command, "PWD") == 0)//PWD
	    {
		stpcpy(reply, "");
		command_pwd(reply);
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
	    }
	    else if(strcmp(command, "CWD") == 0)//CWD
	    {
		stpcpy(reply, "CWD command successful\r\n");
		command_cwd(&buffer[4]);
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
	    }
	    else if(strcmp(command, "POR") == 0)//PORT
	    {
		command_port(&buffer[5], reply);
		write(client_sock, reply, strlen(reply));
		printf("%s", reply);
	    }
	    else if(strcmp(command, "LIS") == 0)//LIST
	    {
		stpcpy(reply, "Opening data connection for file list\r\n");
		write(client_sock, reply, strlen(reply));
		printf("%s", reply);
		command_list(reply);
		
                stpcpy(reply, "Transfer complete\r\n");
		write(client_sock, reply, strlen(reply));
		printf("%s", reply);
	    }
	    else if(strcmp(command, "GET") == 0)//GET
	    {
		sprintf(reply, "Opening  connection to get\r\n");
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
		command_get(&buffer[5], reply);
		stpcpy(reply, "Transfer complete\r\n");
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
	    }
	    else if(strcmp(command, "PUT") == 0)//PUT
	    {
		sprintf(reply, "Opening  connection to put\r\n");
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
		command_put(&buffer[5], reply);
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
	    }
	    else if(strcmp(command, "QUI") == 0)//QUIT
	    {
		stpcpy(reply, "quit.\r\n");
		write(client_sock, reply, strlen(reply));
		printf("%s",  reply);
		break;
	    }
	}
	
	close(client_sock);
	printf("\n");
    }
    close(server_sock);
    return 0;
}




void command_pwd(char *reply)
{
    char buf[255];
    getcwd(buf,sizeof(buf)-1);    //get the current directory
    strcat(reply,buf);
    strcat(reply,"\r\n");
    return;
}

void command_cwd(char *dir)
{
    
    chdir(dir);    //change the directory
}


void command_list(char *reply)
{
    FILE *flist;
    char databuf[PIPE_BUF];
    int n;
    
    //open file list
    flist = popen("ls -l","r");
    if(flist == 0)
    {
	reporterror("popen() failed");
	stpcpy(reply, "Transfer error\r\n");
	close(data_sock);
	return;
    }
    memset(databuf, 0, PIPE_BUF - 1);

    //read the file list 
    while((n = read(fileno(flist), databuf, PIPE_BUF)) > 0)
    {

        printf("write\n");
	write(data_sock, databuf, strlen(databuf));
	memset(databuf, 0, PIPE_BUF - 1);
    }
    memset(databuf, 0, PIPE_BUF - 1);
    if(pclose(flist) != 0)
    {
	reporterror("Non-zero return value from \"ls -l\"");
    }

    //close data socket
    close(data_sock);
    stpcpy(reply, "Transfer complete\r\n");
    return;
}

void command_get(char *filename, char *reply)
{
    FILE *infile;
    unsigned char databuf[FILEBUF_SIZE] = "";
    int bytes;   
    //open file
    infile = fopen(filename,"r");
    if(infile == 0)
    {
	perror("fopen() failed");
	close(data_sock);
	return;
    }
    //read from file and write to the data_sock
    while((bytes = read(fileno(infile), databuf, FILEBUF_SIZE)) > 0)
    {	
	write(data_sock, (const char *)databuf, bytes);	
	memset(&databuf, 0, FILEBUF_SIZE);
    }
    memset(&databuf, 0, FILEBUF_SIZE);   
    //close the file and data socket
    fclose(infile);
    close(data_sock);
    stpcpy(reply, "Transfer complete\r\n");
    return;
}

void command_put(char *filename, char *reply)
{
    FILE *outfile;
    unsigned char databuf[FILEBUF_SIZE];
    struct stat sbuf;
    int bytes = 0;
    //get the file state
    if(stat(filename, &sbuf) == -1)
	printf("Create a new file.\n");

    //open file
    outfile = fopen(filename, "w");
    if(outfile == 0)
    {
	reporterror("fopen() failed");
	stpcpy(reply, "Cannot create the file\r\n");
	close(data_sock);
	return;
    }
    //read from the data sock and write to the file
    while((bytes = read(data_sock, databuf, FILEBUF_SIZE)) > 0)
    {
	write(fileno(outfile), databuf, bytes);
    }
    
    //close the file and the socket
    fclose(outfile);
    close(data_sock);
    stpcpy(reply, "Transfer complete\r\n");
    return;
}


void command_port(char *params, char *reply)
{
    //setup the port for the data connection
    memset(&data_addr, 0, sizeof(data_addr));
    data_addr.sin_family = AF_INET;
    data_addr.sin_addr.s_addr = inet_addr("127.0.0.1");//addr;
    data_addr.sin_port = htons(DATA_PORT);
    //get the data cocket
    data_sock = socket(PF_INET, SOCK_STREAM, 0);
    if(data_sock == -1)
    {
	reporterror("data_sock failed");
	stpcpy(reply, "Cannot get the data socket\r\n");
	return;
    } 
    //connect to the client data socket
    if(connect(data_sock, (struct sockaddr *)&data_addr, sizeof(data_addr)) < 0)
    {
	reporterror("connect()");
	stpcpy(reply, "Cannot connect to the data socket\r\n");
	return;
    }
    stpcpy(reply, "PORT command successful\r\n");
}
